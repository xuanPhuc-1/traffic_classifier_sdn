from scapy.all import *
import random
import os

# Tạo danh sách các địa chỉ IP của các host
host_list = ["10.0.0.1", "10.0.0.2", "10.0.0.3", "10.0.0.4"]

# Gửi các gói tin TCP ngẫu nhiên
while True:
    # Chọn ngẫu nhiên một host nguồn và host đích từ danh sách các host
    src_ip = random.choice(host_list)
    dst_ip = random.choice(host_list)
    
    # Không gửi gói tin từ host này đến chính nó
    if src_ip == dst_ip:
        continue
    
    # Chọn ngẫu nhiên một port nguồn và port đích từ danh sách các port
    src_port = random.randint(1024, 65535)
    dst_port = random.randint(1024, 65535)

    # Tạo một gói tin TCP với kích thước ngẫu nhiên từ 50 đến 100 byte
    pkt = IP(src=src_ip, dst=dst_ip)/TCP(sport=src_port, dport=dst_port)/Raw(RandString(size=random.randint(50, 100)))

    # Gửi gói tin bằng Scapy
    send(pkt, verbose=0)

    # Gửi gói tin bằng hping3 để tăng hiệu suất
    os.system(f"hping3 {dst_ip} -c 1 -s {src_port} -p {dst_port} -d {len(pkt)} >/dev/null 2>&1 &")
